"""Atlas: transparent, dependency-free portfolio research."""
